function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
	// place your drawing code here

}

